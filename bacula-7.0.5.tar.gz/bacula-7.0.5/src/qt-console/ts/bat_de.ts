<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1">
<context>
    <name>ClientForm</name>
    <message>
        <location filename="../clients/clients.ui" line="13"/>
        <source>Client Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="31"/>
        <source>Refresh Client List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="34"/>
        <source>Requery the director for the list of clients.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="42"/>
        <source>List Jobs of Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="45"/>
        <source>Open a joblist page selecting this client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="53"/>
        <source>Status Client In Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="56"/>
        <source>Execute status client in console.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="64"/>
        <source>Purge Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="67"/>
        <source>Purge jobs peformed from this client.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="75"/>
        <source>Prune Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.ui" line="78"/>
        <source>Open the diaolog to prune for this client.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Clients</name>
    <message>
        <location filename="../clients/clients.cpp" line="85"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="81"/>
        <source>Client Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="82"/>
        <source>File Retention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="82"/>
        <source>Job Retention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="82"/>
        <source>AutoPrune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="82"/>
        <source>ClientId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="82"/>
        <source>Uname</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../clients/clients.cpp" line="257"/>
        <source>Are you sure you want to purge ??  !!!.
The Purge command will delete associated Catalog database records from Jobs and Volumes without considering the retention period. Purge  works only on the Catalog database and does not affect data written to Volumes. This command can be dangerous because you can delete catalog records associated with current backups of files, and we recommend that you do not use it unless you know what you are doing.

 Is there any way I can get you to click Cancel here?  You really don&apos;t want to do this

Press OK to proceed with the purge operation?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConsoleForm</name>
    <message>
        <location filename="../console/console.ui" line="13"/>
        <source>Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../console/console.ui" line="85"/>
        <source>StatusDir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../console/console.ui" line="93"/>
        <source>Console Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../console/console.ui" line="101"/>
        <source>Request Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../console/console.ui" line="109"/>
        <source>Reload bacula-dir.conf</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DirComm</name>
    <message>
        <location filename="../bcomm/dircomm.cpp" line="523"/>
        <source>Bat</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DirStat</name>
    <message>
        <location filename="../status/dirstat.cpp" line="235"/>
        <source>Job Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="235"/>
        <source>Job Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="137"/>
        <source>Job Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="137"/>
        <source>Job Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="137"/>
        <source>Job Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="191"/>
        <source>Job Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="191"/>
        <source>Job Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="190"/>
        <source>Job Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="190"/>
        <source>Priority</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="191"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="235"/>
        <source>Job Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="235"/>
        <source>Job Info</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.cpp" line="45"/>
        <source>Director Status</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DirStatForm</name>
    <message>
        <location filename="../status/dirstat.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.ui" line="102"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;Scheduled Jobs&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.ui" line="131"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;Running Jobs&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../status/dirstat.ui" line="160"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:13pt; font-weight:600;&quot;&gt;Terminated Jobs&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSet</name>
    <message>
        <location filename="../fileset/fileset.cpp" line="46"/>
        <source>FileSets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.cpp" line="82"/>
        <source>  FileSet Name  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.cpp" line="83"/>
        <source>FileSet Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.cpp" line="83"/>
        <source>Create Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.cpp" line="86"/>
        <source>FileSet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileSetForm</name>
    <message>
        <location filename="../fileset/fileset.ui" line="13"/>
        <source>FileSet Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.ui" line="31"/>
        <source>Refresh FileSet List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.ui" line="34"/>
        <source>Requery the director for the list of storage objects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.ui" line="42"/>
        <source>Status FileSet In Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../fileset/fileset.ui" line="50"/>
        <source>ShowJobs</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Help</name>
    <message>
        <location filename="../help/help.cpp" line="61"/>
        <source>Help: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobList</name>
    <message>
        <location filename="../joblist/joblist.cpp" line="319"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="235"/>
        <source>Job Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="232"/>
        <source>Job Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="232"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="239"/>
        <source>Job Starttime</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="237"/>
        <source>Job Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="242"/>
        <source>Job Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="240"/>
        <source>Job Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="241"/>
        <source>Job Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="238"/>
        <source>Job Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="236"/>
        <source>Purged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="234"/>
        <source>File Set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="295"/>
        <source>IS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="296"/>
        <source>NOT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="299"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="300"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="324"/>
        <source>The Jobs query returned no results.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="539"/>
        <source>Are you sure you want to delete??  !!!.
This delete command is used to delete a Job record and all associated catalog records that were created. This command operates only on the Catalog database and has no effect on the actual data written to a Volume. This command can be dangerous and we strongly recommend that you do not use it unless you know what you are doing.  The Job and all its associated records (File and JobMedia) will be deleted from the catalog.Press OK to proceed with delete operation.?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.cpp" line="557"/>
        <source>Are you sure you want to purge ??  !!!.
The Purge command will delete associated Catalog database records from Jobs and Volumes without considering the retention period. Purge  works only on the Catalog database and does not affect data written to Volumes. This command can be dangerous because you can delete catalog records associated with current backups of files, and we recommend that you do not use it unless you know what you are doing.
Press OK to proceed with the purge operation?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobListForm</name>
    <message>
        <location filename="../joblist/joblist.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="88"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="98"/>
        <source>Graph</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="124"/>
        <source>FileSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="154"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="174"/>
        <source>Purged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="204"/>
        <source>Record Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="234"/>
        <source>Days Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="268"/>
        <source>Clients</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="288"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="318"/>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="338"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="356"/>
        <source>Refresh Job List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="359"/>
        <source>Requery the director for the list of jobs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="367"/>
        <source>ListJobid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="375"/>
        <source>List Files On Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="383"/>
        <source>ListJobMedia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="391"/>
        <source>ListVolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="399"/>
        <source>DeleteJob</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="407"/>
        <source>PurgeFiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="415"/>
        <source>Restore From Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="423"/>
        <source>Restore From Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="431"/>
        <source>Show Log for Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="439"/>
        <source>Cancel Currently Running Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblist/joblist.ui" line="447"/>
        <source>List Job Totals in Console</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobLog</name>
    <message>
        <location filename="../joblog/joblog.cpp" line="110"/>
        <source>Bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../joblog/joblog.cpp" line="113"/>
        <source>There were no results ??  !!!.
It is possible you may need to add &quot;catalog = all&quot; to the Messages stanza for this job.
</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobLogForm</name>
    <message>
        <location filename="../joblog/joblog.ui" line="13"/>
        <source>Job Log</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobPlot</name>
    <message>
        <location filename="../jobgraphs/jobplot.cpp" line="312"/>
        <source>Bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplot.cpp" line="314"/>
        <source>The Jobs query returned no results.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>JobPlotControlsForm</name>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="27"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="81"/>
        <source>File Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="88"/>
        <source>Byte Data</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="147"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="238"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="245"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="252"/>
        <source>Purged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="265"/>
        <source>FileSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="272"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="279"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="286"/>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="293"/>
        <source>Days Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="308"/>
        <source>Record Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="315"/>
        <source>Byte Symbol Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="322"/>
        <source>File Symbol Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobgraphs/jobplotcontrols.ui" line="329"/>
        <source>Graph Type</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Jobs</name>
    <message>
        <location filename="../jobs/jobs.cpp" line="85"/>
        <source>Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="78"/>
        <source>Job Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="78"/>
        <source>Pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="79"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="79"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="79"/>
        <source>Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="79"/>
        <source>Where</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="79"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="83"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="81"/>
        <source>FileSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="81"/>
        <source>Catalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="81"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.cpp" line="165"/>
        <source>Backup</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainForm</name>
    <message>
        <location filename="../main.ui" line="14"/>
        <source>bat - Bacula Admin Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="23"/>
        <source>Bacula Administration Tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="26"/>
        <source>It&apos;s a Dock widget to allow page selection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="79"/>
        <source>&amp;Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="87"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="94"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="101"/>
        <source>&amp;File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="117"/>
        <source>Current Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="128"/>
        <source>Tool Bar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="188"/>
        <source>Page Selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="233"/>
        <source>Selects panel window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="236"/>
        <source>Use items in this tree to select what window is in panel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="248"/>
        <source>Console Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="251"/>
        <source>Enter a bacula command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="254"/>
        <source>Console Command entry Dock Widget</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="263"/>
        <source>Console Command Line Entry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="287"/>
        <source>Command:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="294"/>
        <source>Click here to enter command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="305"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="308"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="316"/>
        <source>&amp;About bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="324"/>
        <source>&amp;Copy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="332"/>
        <source>Cu&amp;t</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="340"/>
        <source>new</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="348"/>
        <source>open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="356"/>
        <source>&amp;Paste</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="364"/>
        <source>&amp;Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="367"/>
        <source>Print</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="375"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="378"/>
        <source>Save (not implemented)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="386"/>
        <source>Connect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="389"/>
        <source>Connect/disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="397"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="403"/>
        <source>Label a Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="411"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="414"/>
        <source>Restore Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="431"/>
        <source>Run Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="434"/>
        <source>Run a Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="451"/>
        <source>Estimate Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="454"/>
        <source>Estimate a Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="462"/>
        <source>Status Dir</source>
        <comment>Query status of director</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="465"/>
        <source>Status Dir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="471"/>
        <source>Query status of director in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="479"/>
        <source>&amp;Select Font ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="487"/>
        <source>Undock Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="490"/>
        <source>Undock Current Window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="498"/>
        <source>ToggleDock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="504"/>
        <source>Toggle Dock Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="512"/>
        <source>Close Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="515"/>
        <source>Close The Current Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="523"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="526"/>
        <source>Display any messages queued at the director</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="534"/>
        <source>&amp;Preferences ...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="540"/>
        <source>Set Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="548"/>
        <source>bat &amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="556"/>
        <source>Browse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="562"/>
        <source>Browse Cataloged Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="570"/>
        <source>JobPlot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="576"/>
        <source>Plot Job Files and Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="584"/>
        <source>Status Dir Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../main.ui" line="587"/>
        <source>Director Status Page</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWin</name>
    <message>
        <location filename="../mainwin.cpp" line="477"/>
        <source>Director not connected. Click on connect button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwin.cpp" line="488"/>
        <source>About bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwin.cpp" line="490"/>
        <source>&lt;br&gt;&lt;h2&gt;bat 1.0, by Dirk H Bartley and Kern Sibbald&lt;/h2&gt;&lt;p&gt;Copyright &amp;copy; 2007-</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mainwin.cpp" line="513"/>
        <source> Ready</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MediaEdit</name>
    <message>
        <location filename="../mediaedit/mediaedit.cpp" line="47"/>
        <source>Media Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.cpp" line="196"/>
        <source>No Volume name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.cpp" line="196"/>
        <source>No Volume name given</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MediaList</name>
    <message>
        <location filename="../medialist/medialist.cpp" line="50"/>
        <source>Media</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="83"/>
        <source>Volume Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="83"/>
        <source>Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="83"/>
        <source>Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="86"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="83"/>
        <source>Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="84"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="84"/>
        <source>Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="84"/>
        <source>Retention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="84"/>
        <source>Media Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="84"/>
        <source>Slot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="85"/>
        <source>Use Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="85"/>
        <source>Max Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="85"/>
        <source>Max Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="85"/>
        <source>Max Bytes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="85"/>
        <source>Recycle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="86"/>
        <source>RecyclePool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="86"/>
        <source>Last Written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="101"/>
        <source>Pools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="323"/>
        <source>Are you sure you want to delete??  !!!.
This delete command is used to delete a Volume record and all associated catalog records that were created. This command operates only on the Catalog database and has no effect on the actual data written to a Volume. This command can be dangerous and we strongly recommend that you do not use it unless you know what you are doing.  All Jobs and all associated records (File and JobMedia) will be deleted from the catalog.Press OK to proceed with delete operation.?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.cpp" line="345"/>
        <source>Are you sure you want to purge ??  !!!.
The Purge command will delete associated Catalog database records from Jobs and Volumes without considering the retention period. Purge  works only on the Catalog database and does not affect data written to Volumes. This command can be dangerous because you can delete catalog records associated with current backups of files, and we recommend that you do not use it unless you know what you are doing.
Press OK to proceed with the purge operation?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MediaListForm</name>
    <message>
        <location filename="../medialist/medialist.ui" line="13"/>
        <source>Media Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="31"/>
        <source>Refresh Media List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="34"/>
        <source>Requery the director for the list of media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="42"/>
        <source>Edit Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="50"/>
        <source>List Jobs On Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="58"/>
        <source>Delete Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="66"/>
        <source>Prune Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="74"/>
        <source>Purge Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="82"/>
        <source>Relabel Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="99"/>
        <source>Update all Volumes From Pool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="116"/>
        <source>Update all Volumes from all Pools</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../medialist/medialist.ui" line="124"/>
        <source>Volume From Pool</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Pages</name>
    <message>
        <location filename="../pages.cpp" line="264"/>
        <source> of Director </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages.cpp" line="294"/>
        <source>UnDock </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages.cpp" line="296"/>
        <source>ReDock </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../pages.cpp" line="298"/>
        <source> Window</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PrefsForm</name>
    <message>
        <location filename="../prefs.ui" line="19"/>
        <source>Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="50"/>
        <source>Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="80"/>
        <source>Messages Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="104"/>
        <source>Message check interval in seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="111"/>
        <source>Check Messages</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="129"/>
        <source>Joblist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="159"/>
        <source>Joblist Limit Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="203"/>
        <source>Days Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="236"/>
        <source>Record Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="249"/>
        <source>Misc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="261"/>
        <source>Convert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="273"/>
        <source>Convert Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="286"/>
        <source>Convert Bytes with IEC 1000B = KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="299"/>
        <source>Convert Bytes with 1024B = KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="313"/>
        <source>Context Sensitive List Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="337"/>
        <source>Execute Long List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="353"/>
        <source>GroupBox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="365"/>
        <source>Open Plot page on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="378"/>
        <source>Open Browser page on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="391"/>
        <source>Open Director Status page on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="398"/>
        <source>Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="543"/>
        <source>Debugging Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="472"/>
        <source>Debug comm</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="479"/>
        <source>Display all messages in console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="486"/>
        <source>Debug Commands</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="493"/>
        <source>Debug Sql queries</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="500"/>
        <source>Debug Miscelaneous Items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="513"/>
        <source>RestoreTree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="587"/>
        <source>Restore Debug 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="594"/>
        <source>Directory Item Changed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="601"/>
        <source>Restore Debug 1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="608"/>
        <source>Directory Current Item Changed Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="615"/>
        <source>Update File Table Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="622"/>
        <source>Version Table Item Changed Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="629"/>
        <source>File Table Item Changed Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="636"/>
        <source>Icon State Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="643"/>
        <source>Update Checks Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="650"/>
        <source>Restore Debug 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="657"/>
        <source>Update Version Table Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="664"/>
        <source>Populate Directory Debug</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../prefs.ui" line="726"/>
        <source>&lt;h2&gt;Preferences&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Storage</name>
    <message>
        <location filename="../storage/storage.cpp" line="87"/>
        <source>Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.cpp" line="83"/>
        <source>Storage Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.cpp" line="84"/>
        <source>Storage Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.cpp" line="84"/>
        <source>Auto Changer</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>StorageForm</name>
    <message>
        <location filename="../storage/storage.ui" line="13"/>
        <source>Storage Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="31"/>
        <source>Refresh Storage List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="34"/>
        <source>Requery the director for the list of storage objects.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="45"/>
        <source>Status Storage In Console</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="56"/>
        <source>Label Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="67"/>
        <source>MountStorage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="78"/>
        <source>UnMount Storage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="89"/>
        <source>Update Slots</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="100"/>
        <source>Update Slots Scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../storage/storage.ui" line="108"/>
        <source>Release</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>bRestoreForm</name>
    <message>
        <location filename="../restore/brestore.ui" line="13"/>
        <source>brestore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="41"/>
        <source>File list</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="217"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="67"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="242"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="135"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="94"/>
        <source>File revisions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="115"/>
        <source>InChanger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="120"/>
        <source>Volume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="227"/>
        <source>JobId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="140"/>
        <source>Chksum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="167"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Restore items list&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="190"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="197"/>
        <source>Estimate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="204"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="222"/>
        <source>FileName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="232"/>
        <source>FileIndex</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="237"/>
        <source>Nb Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/brestore.ui" line="288"/>
        <source>Location</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>estimateForm</name>
    <message>
        <location filename="../run/estimate.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="44"/>
        <source>List Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="77"/>
        <source>Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="93"/>
        <source>Client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="112"/>
        <source>Job:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="122"/>
        <source>FileSet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="161"/>
        <source>&lt;h3&gt;Estimate a backup Job&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="204"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/estimate.ui" line="211"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>estimatePage</name>
    <message>
        <location filename="../run/estimate.cpp" line="47"/>
        <source>Estimate</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>helpForm</name>
    <message>
        <location filename="../help/help.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../help/help.ui" line="36"/>
        <source>&amp;Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../help/help.ui" line="43"/>
        <source>&amp;Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../help/help.ui" line="63"/>
        <source>Close</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>jobsForm</name>
    <message>
        <location filename="../jobs/jobs.ui" line="13"/>
        <source>Client Tree</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="31"/>
        <source>Refresh Jobs List</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="34"/>
        <source>Requery the director for the list of clients.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="51"/>
        <source>List Files Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="68"/>
        <source>List Volumes Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="85"/>
        <source>List Next Volume Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="102"/>
        <source>Enable Job Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="119"/>
        <source>Disable Job Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="136"/>
        <source>Open JobList on Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="147"/>
        <source>Cancel Job Command</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../jobs/jobs.ui" line="155"/>
        <source>RunJob</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>labelForm</name>
    <message>
        <location filename="../label/label.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="86"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="93"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="102"/>
        <source>Volume Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="115"/>
        <source>Storage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="142"/>
        <source>Slot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="160"/>
        <source>Execute Automount</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="167"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="174"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="199"/>
        <source>Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../label/label.ui" line="236"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Label a Volume&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mediaEditForm</name>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="33"/>
        <source>Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="43"/>
        <source>Volume Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="50"/>
        <source>Max Volume Bytes:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="66"/>
        <source>Slot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="76"/>
        <source>Max Volume Jobs:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="86"/>
        <source>Use Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="117"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="124"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="140"/>
        <source>Retension:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="150"/>
        <source>Recycle Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="171"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="200"/>
        <source>Max Volume Files:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="241"/>
        <source>Years</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="248"/>
        <source>Seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="265"/>
        <source>Use Duration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="285"/>
        <source>Days</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="302"/>
        <source>Hours</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="309"/>
        <source>Months</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="339"/>
        <source>Retention</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="356"/>
        <source>Minutes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="399"/>
        <source>Volume : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="442"/>
        <source>Recycle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mediaedit/mediaedit.ui" line="491"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Edit a Volume&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>mountForm</name>
    <message>
        <location filename="../mount/mount.ui" line="16"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mount/mount.ui" line="34"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mount/mount.ui" line="52"/>
        <source>Slot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../mount/mount.ui" line="124"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Mount a Slot&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>prefsDialog</name>
    <message>
        <location filename="../mainwin.cpp" line="768"/>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>prerestoreForm</name>
    <message>
        <location filename="../restore/prerestore.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="51"/>
        <source>All Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="61"/>
        <source>Select Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="126"/>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="136"/>
        <source>JobIds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="176"/>
        <source>yyyy-mm-dd h:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="189"/>
        <source>Use Most Recent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="196"/>
        <source>File Set:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="206"/>
        <source>Client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="219"/>
        <source>Storage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="232"/>
        <source>Before:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="245"/>
        <source>Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="292"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="299"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.ui" line="391"/>
        <source>&lt;h3&gt;Select Jobs&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>prerestorePage</name>
    <message>
        <location filename="../restore/prerestore.cpp" line="62"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="76"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="104"/>
        <source>Comma separted list of Job Ids</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="194"/>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="274"/>
        <source>There can be no spaces in the text for the joblist.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="306"/>
        <source>The string is not a comma separated list of integers.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="310"/>
        <source>Bat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="312"/>
        <source>At least one of the jobs is not a valid job of type &quot;Backup&quot;.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/prerestore.cpp" line="318"/>
        <source>All jobs in the list must be of the same jobName and same client.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>pruneForm</name>
    <message>
        <location filename="../run/prune.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="41"/>
        <source>Prune Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="63"/>
        <source>Volume:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="103"/>
        <source>&lt;h3&gt;Prune Files/Jobs/Volumes&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="133"/>
        <source>Prune Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="176"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="183"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="201"/>
        <source>Client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.ui" line="219"/>
        <source>Prune Volumes</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>prunePage</name>
    <message>
        <location filename="../run/prune.cpp" line="47"/>
        <source>Prune</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.cpp" line="140"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/prune.cpp" line="124"/>
        <source> Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>relabelDialog</name>
    <message>
        <location filename="../relabel/relabel.cpp" line="53"/>
        <source>From Volume : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.cpp" line="64"/>
        <source>No Volume name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.cpp" line="64"/>
        <source>No Volume name given</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.cpp" line="70"/>
        <source>New name must be different</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>relabelForm</name>
    <message>
        <location filename="../relabel/relabel.ui" line="16"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="34"/>
        <source>From Volume :</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="101"/>
        <source>Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="111"/>
        <source>Storage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="134"/>
        <source>New Volume Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="147"/>
        <source>Slot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../relabel/relabel.ui" line="186"/>
        <source>&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal; text-decoration:none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-size:12pt; font-weight:600;&quot;&gt;Relabel a Volume&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>restoreForm</name>
    <message>
        <location filename="../restore/restore.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="123"/>
        <source>1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="128"/>
        <source>2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="133"/>
        <source>3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="138"/>
        <source>4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="143"/>
        <source>5</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="148"/>
        <source>6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="190"/>
        <source>&lt;h2&gt;Directories&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="219"/>
        <source>&lt;h3&gt;Restore Select&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="254"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="469"/>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="298"/>
        <source>Unmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="324"/>
        <source>&lt;h2&gt;Files&lt;/h2&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="369"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="414"/>
        <source>Current Dir:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="450"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="457"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.ui" line="477"/>
        <source>UnMark</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>restorePage</name>
    <message>
        <location filename="../restore/restore.cpp" line="46"/>
        <source>Restore Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="74"/>
        <source>Mark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="74"/>
        <source>File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="74"/>
        <source>Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="75"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="75"/>
        <source>Group</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="75"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="75"/>
        <source>Date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="189"/>
        <source>In addDirectory cwd &quot;%1&quot; newdir &quot;%2&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="236"/>
        <source>In else of if parent cwd &quot;%1&quot; newdir &quot;%2&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restore.cpp" line="286"/>
        <source>Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>restoreTree</name>
    <message>
        <location filename="../restore/restoretree.cpp" line="45"/>
        <source>Version Browser</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="118"/>
        <source>Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="755"/>
        <source>Any</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="142"/>
        <source>Refresh From Re-Select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="145"/>
        <source>Refresh From JobChecks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="238"/>
        <source>Task </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="181"/>
        <source>Querying Database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="198"/>
        <source>Querying Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="241"/>
        <source>Querying for Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="249"/>
        <source>Processing Directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="281"/>
        <source>No jobs were selected in the job query !!!.
Press OK to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="384"/>
        <source>In addDirectory cwd &quot;%1&quot; newdir &quot;%2&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="438"/>
        <source>In else of if parent cwd &quot;%1&quot; newdir &quot;%2&quot;
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="511"/>
        <source>File Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="511"/>
        <source>Filename Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="521"/>
        <source>Present Working Directory : </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="735"/>
        <source>Job Id</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="616"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="735"/>
        <source>End Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="616"/>
        <source>Hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="616"/>
        <source>FileId</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="702"/>
        <source>RestoreTreePage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="736"/>
        <source>Level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="736"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="739"/>
        <source>Purged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="737"/>
        <source>TU</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.cpp" line="738"/>
        <source>TD</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>restoreTreeForm</name>
    <message>
        <location filename="../restore/restoretree.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="38"/>
        <source>Jobs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="205"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="108"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="131"/>
        <source>Versions of File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="141"/>
        <source>FileName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="195"/>
        <source>Refresh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="212"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="232"/>
        <source>Job</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="250"/>
        <source>Job List Job Criterion Selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="267"/>
        <source>Client</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="285"/>
        <source>Job List Client Criterion Selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="302"/>
        <source>FileSet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="320"/>
        <source>Job List Fileset Criterion Selector</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="337"/>
        <source>Record Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="367"/>
        <source>Days Limit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="396"/>
        <source>Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="407"/>
        <source>Select Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../restore/restoretree.ui" line="415"/>
        <source>UnselectDirectory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>runCmdForm</name>
    <message>
        <location filename="../run/runcmd.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="41"/>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="157"/>
        <source>yyyy-mm-dd hh:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="167"/>
        <source>When:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="177"/>
        <source>Where:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="190"/>
        <source>Bootstrap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="206"/>
        <source>Job:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="232"/>
        <source>Storage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="242"/>
        <source>FileSet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="277"/>
        <source>Replace:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="287"/>
        <source>To client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="297"/>
        <source>Catalog:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="330"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="337"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.ui" line="376"/>
        <source>&lt;h3&gt;Run Restore Job&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>runCmdPage</name>
    <message>
        <location filename="../run/runcmd.cpp" line="51"/>
        <source>Restore Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.cpp" line="79"/>
        <source>never</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.cpp" line="77"/>
        <source>always</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.cpp" line="78"/>
        <source>ifnewer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.cpp" line="78"/>
        <source>ifolder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/runcmd.cpp" line="177"/>
        <source> Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>runForm</name>
    <message>
        <location filename="../run/run.ui" line="13"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="33"/>
        <source>Level:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="46"/>
        <source>Bootstrap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="91"/>
        <source>yyyy-mm-dd hh:mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="101"/>
        <source>Job:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="124"/>
        <source>Pool:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="142"/>
        <source>Type:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="149"/>
        <source>&lt;h3&gt;Backup&lt;h3/&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="158"/>
        <source>FileSet:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="168"/>
        <source>Messages:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="205"/>
        <source>&lt;h3&gt;Run a Job&lt;/h3&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="230"/>
        <source>Priority:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="243"/>
        <source>Client:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="274"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="281"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="306"/>
        <source>Storage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.ui" line="319"/>
        <source>When:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>runPage</name>
    <message>
        <location filename="../run/run.cpp" line="47"/>
        <source>Run</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../run/run.cpp" line="117"/>
        <source> Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>selectDialog</name>
    <message>
        <location filename="../select/select.cpp" line="83"/>
        <source> Canceled</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>selectForm</name>
    <message>
        <location filename="../select/select.ui" line="16"/>
        <source>Selection dialog</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>yesnoPopUp</name>
    <message>
        <location filename="../select/select.cpp" line="111"/>
        <source>Bat Question</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
