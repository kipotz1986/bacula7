#
# See the file <bacula-source>/examples/sample-query.sql
#  for some sample queries. 
#
# 1
:The default file is empty, see <bacula-source>/examples/sample-query.sql for samples
SELECT 'See <bacula-source>/examples/sample-query.sql for samples' AS Info;
